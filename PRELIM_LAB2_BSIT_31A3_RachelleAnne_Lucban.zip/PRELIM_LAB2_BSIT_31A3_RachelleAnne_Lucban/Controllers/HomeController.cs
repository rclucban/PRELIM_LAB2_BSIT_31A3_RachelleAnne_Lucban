
using Microsoft.AspNetCore.Mvc;
using PRELIM_LAB2_BSIT_31A3_RachelleAnne_Lucban.Models;


namespace YourProjectName.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
           
            var book = new Book
            {
                Id = 1,
                Title = "The Great Adventure",
                Author = "Jane Doe"
            };

           
            var customer = new Customer
            {
                Title = "Ms.",
                FirstName = "Rachelle Anne",
                MiddleName = "C.", // 
                LastName = "Lucban",
                Email = "rclucban@example.com"
            };

            var viewModel = new HomeViewModel
            {
                Book = book,
                Customer = customer
            };

            return View(viewModel); 
        }

        public IActionResult Privacy()
        {
            return View();
        }

       
    }
}