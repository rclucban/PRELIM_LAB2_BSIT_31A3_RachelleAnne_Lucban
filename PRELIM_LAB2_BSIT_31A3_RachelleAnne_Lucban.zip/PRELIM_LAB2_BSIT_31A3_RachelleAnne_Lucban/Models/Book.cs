﻿namespace PRELIM_LAB2_BSIT_31A3_RachelleAnne_Lucban.Models
{
    public class Book
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
    }
}
