namespace PRELIM_LAB2_BSIT_31A3_RachelleAnne_Lucban.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
