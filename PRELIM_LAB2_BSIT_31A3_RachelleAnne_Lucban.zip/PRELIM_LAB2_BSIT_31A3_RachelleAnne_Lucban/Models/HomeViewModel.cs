﻿namespace PRELIM_LAB2_BSIT_31A3_RachelleAnne_Lucban.Models
{
    public class HomeViewModel
    {
        public Book Book { get; set; }
        public Customer Customer { get; set; }
    }
}
