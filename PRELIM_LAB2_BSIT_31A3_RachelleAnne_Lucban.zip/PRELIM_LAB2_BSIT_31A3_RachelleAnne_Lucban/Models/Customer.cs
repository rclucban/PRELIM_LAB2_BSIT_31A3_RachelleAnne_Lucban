﻿// Models/Customer.cs
namespace PRELIM_LAB2_BSIT_31A3_RachelleAnne_Lucban.Models
{
    public class Customer
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public string Title { get; set; } // e.g., "Mr", "Ms.", "Mrs.", "Sir"
        public string Email { get; set; }

        // Read-only property for FullName (Encapsulation)
        public string FullName
        {
            get
            {
                // Combine Title, FirstName, MiddleName (if exists), and LastName
                string full = "";
                if (!string.IsNullOrEmpty(Title))
                {
                    full += Title + " ";
                }
                full += FirstName;
                if (!string.IsNullOrEmpty(MiddleName))
                {
                    full += " " + MiddleName;
                }
                full += " " + LastName;
                return full.Trim(); // Remove any leading/trailing spaces
            }
        }
    }
}